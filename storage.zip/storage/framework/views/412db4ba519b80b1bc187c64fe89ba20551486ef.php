<!DOCTYPE html>
<html lang="fr">

<head> 

    <!-- Basic Page Needs
    ================================================== -->
    <title>chingInfo</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="chingInfo est une plateforme des exercices de module informatique">

    <!-- Favicon -->
    <link href="<?php echo e(asset('assets/images/favicon.png')); ?>" rel="icon" type="image/png">

    <!-- icons
    ================================================== -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/icons.css')); ?>">

    <!-- CSS
    ================================================== -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/uikit.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">

</head>

<body>

    <div id="wrapper" class="is-verticle">

        <!--  Header  -->
        <header class="is-transparent is-dark border-b backdrop-filter backdrop-blur-2xl" uk-sticky="cls-inactive: is-dark is-transparent border-b"> 
            <div class="header_inner">
                <div class="left-side">
    
                    <!-- Logo -->
                    <div id="logo">
                        <a href=" <?php echo e(route('accueil')); ?> ">
                            <img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="">
                            <img src="<?php echo e(asset('assets/images/logo-light.png')); ?>" class="logo_inverse" alt="">
                            <img src="<?php echo e(asset('assets/images/logo-mobile.png')); ?>" class="logo_mobile" alt="">
                        </a>
                    </div>
    
                    <!-- icon menu for mobile -->
                    <div class="triger" uk-toggle="target: #wrapper ; cls: is-active">
                    </div>
    
                </div>
                <div class="right-side">
     
                    <!-- Header search box  -->
                    <div class="header_search"><ion-icon name="search" class="icon-search">
                    </ion-icon>
                        <input value="" type="text" class="form-control" placeholder=" Recherche rapide ..." autocomplete="off">
                        
                    </div>

                    <div>

                       
        
                         <!-- profile -->
                        <a href="#">
                            <img src="../assets/images/avatars/placeholder.png" class="header_widgets_avatar" alt="">
                        </a>
                        <div uk-drop="mode: click;offset:5" class="header_dropdown profile_dropdown">
                            <ul>   
                                <li>
                                    <a href="#" class="user">
                                        <div class="user_avatar">
                                            <img src="../assets/images/avatars/avatar-2.jpg" alt="">
                                        </div>
                                        <div class="user_name">
                                            <div> Stella Johnson </div>
                                            <span> @Johnson  </span>
                                        </div>
                                    </a>
                                </li>
                                <li> 
                                    <hr>
                                </li>
                                <li> 
                                    <a href="#" class="is-link">
                                        <ion-icon name="rocket-outline" class="is-icon"></ion-icon> <span>  Upgrade Membership  </span>
                                    </a>
                                </li> 
                                <li> 
                                    <hr>
                                </li>
                                <li> 
                                    <a href="#">
                                        <ion-icon name="person-circle-outline" class="is-icon"></ion-icon>
                                         My Account 
                                    </a>
                                </li>
                                <li> 
                                    <a href="#">
                                        <ion-icon name="card-outline" class="is-icon"></ion-icon>
                                        Subscriptions
                                    </a>
                                </li>
                                <li> 
                                    <a href="#">
                                        <ion-icon name="color-wand-outline" class="is-icon"></ion-icon>
                                        My Billing 
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <ion-icon name="settings-outline" class="is-icon"></ion-icon>
                                        Account Settings  
                                    </a>
                                </li>
                                <li> 
                                    <hr>
                                </li>
                                <li> 
                                    <a href="#" id="night-mode" class="btn-night-mode" onclick="UIkit.notification({ message: 'Hmm...  <strong> Night mode </strong> feature is not available yet. ' , pos: 'bottom-right'  })">
                                        <ion-icon name="moon-outline" class="is-icon"></ion-icon>
                                         Night mode
                                        <span class="btn-night-mode-switch">
                                            <span class="uk-switch-button"></span>
                                        </span>
                                    </a>
                                </li>
                                <li> 
                                    <a href="#">
                                        <ion-icon name="log-out-outline" class="is-icon"></ion-icon>
                                        Log Out 
                                    </a>
                                </li>
                            </ul>
                        </div> 

                    </div>
    
                </div>
            </div>
        </header>

        <!-- Main Contents -->
        <div class="main_content">
            <div class="container">
                
                <div class="md:p-7 p-5 bg-white rounded-md shadow lg:mt-10 mt-6">

                    <h3 class="md:text-2xl text-xl mt-4 mb-1 font-bold"> Tous les exercices </mark> </h3>
                    <p class="mb-8"> Faites vos choix !!!</p>
        
                    <div class="grid lg:grid-cols-3 md:grid-cols-2 md:gap-4 gap-2 -m-3">
                        <?php $__currentLoopData = $exercises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exercise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href=" <?php echo e(route('exercice', ['slug' => $exercise->slug])); ?> ">
                                <div class="hover:bg-gray-100 flex items-start px-3 py-2 rounded-lg space-x-3">
                                    <?php if($exercise->id%9 == 0): ?>
                                        <?php $color = 'blue' ?>
                                    <?php elseif($exercise->id%7 == 0): ?>
                                        <?php $color = 'purple' ?>
                                    <?php elseif($exercise->id%5 == 0): ?>
                                        <?php $color = 'yellow' ?>
                                    <?php elseif($exercise->id%3 == 0): ?>
                                        <?php $color = 'green' ?>
                                    <?php elseif($exercise->id%2 == 0): ?>
                                        <?php $color = 'pink' ?>
                                    <?php else: ?>
                                        <?php $color = 'red' ?>
                                    <?php endif; ?>
                                    <?php if($exercise->id<10): ?>
                                        <?php $x = '5' ?>
                                    <?php elseif($exercise->id>9 and $exercise->id<100): ?>
                                        <?php $x = '3.5' ?>
                                    <?php else: ?>
                                    <?php $x = '1' ?>
                                    <?php endif; ?>
                                    <div class="text-3xl text-white from-<?php echo e($color); ?>-600 to-<?php echo e($color); ?>-400 bg-gradient-to-tl p-2 px-<?php echo e($x); ?> rounded-md"><?php echo e($exercise->id); ?></div>
                                    <div>
                                        <h3 class="font-semibold text-lg"><?php echo e($exercise->title); ?></h3>
                                        <div class="flex space-x-2 items-center text-sm pt-0.5">
                                            <div> Exercice </div>
                                            <div>N°</div>
                                            <div> <?php echo e($exercise->id); ?></div>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>


                    <div class="flex justify-center mt-9">
                        <a href="#" class="bg-gray-50 border hover:bg-gray-100 px-4 py-1.5 rounded-full text-sm"> More Topics ..</a>
                    </div>

                </div>

            </div>

            <!-- footer -->
            <div class="lg:mt-28 mt-10 mb-7 px-12 border-t pt-7">
                <div class="flex flex-col items-center justify-between lg:flex-row max-w-6xl mx-auto lg:space-y-0 space-y-3">
                    <p class="capitalize font-medium"> © copyright <script>document.write(new Date().getFullYear())</script>  Courseplus</p>
                    <div class="lg:flex space-x-4 text-gray-700 capitalize hidden">
                        <a href=" <?php echo e(route('accueil')); ?> "> Accueil</a>
                        <a href="#"> Aide</a>
                        <a href="#"> Nous contactez</a>
                    </div>
                </div>
            </div>
        </div>
 
        <!-- sidebar -->
        <div class="sidebar">
            <div class="sidebar_inner" data-simplebar>
                
                <ul class="side-colored">
                    <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li 
                            <?php if($loop->odd): ?>
                                class="active"
                            <?php endif; ?>
                        >
                            <a href=" <?php echo e(route('module', ['slug' =>$module->slug])); ?> ">
                                <ion-icon name="<?php echo e($module->icon); ?>" class="bg-gradient-to-br from-purple-300 p-1 rounded-md side-icon text-opacity-80 text-white to-blue-500">
                                </ion-icon>
                                <span> <?php echo e($module->title); ?></span>
                            </a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>


            </div>

        </div>
        
    </div>


    <!-- Javascript
    ================================================== -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/uikit@3.7.6/dist/js/uikit.min.js"></script>
    <script src="<?php echo e(asset('assets/js/uikit.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/tippy.all.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/simplebar.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap-select.min.js')); ?>"></script>
    <script src="https://unpkg.com/ionicons@5.2.3/dist/ionicons.js"></script>

</body>

</html><?php /**PATH C:\Users\eloss\Documents\Code_Lab\Laravel_Lab\chingInfo\resources\views/exercise/all.blade.php ENDPATH**/ ?>
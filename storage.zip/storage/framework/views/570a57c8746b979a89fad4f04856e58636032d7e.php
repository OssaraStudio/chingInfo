<!DOCTYPE html>
<html lang="fr">

<head> 

    <!-- Basic Page Needs
    ================================================== -->
    <title>chingInfo</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="chingInfo est une plateforme des exercices de module informatique">

    <!-- Favicon -->
    <link href="<?php echo e(asset('assets/images/favicon.png')); ?>" rel="icon" type="image/png">

    <!-- icons
    ================================================== -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/icons.css')); ?>">

    <!-- CSS
    ================================================== -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/uikit.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">

</head>

<body>

    <div id="wrapper" class="is-verticle">

        <!--  Header  -->
        <header uk-sticky="" class="uk-sticky uk-sticky-fixed" style="position: fixed; top: 0px; width: 1301px;"> 
            <div class="header_inner">
                <div class="left-side">
    
                    <!-- Logo -->
                    <div id="logo">
                        <a href=" <?php echo e(route('accueil')); ?> ">
                            <img src=" <?php echo e(asset('assets/images/logo.png')); ?> " alt="">
                            <img src=" <?php echo e(asset('assets/images/logo-light.png')); ?> " class="logo_inverse" alt="">
                            <img src=" <?php echo e(asset('assets/images/logo-mobile.png')); ?> " class="logo_mobile" alt="">
                        </a>
                    </div>
    
                    <!-- icon menu for mobile -->
                    <div class="triger" uk-toggle="target: #wrapper ; cls: is-active" tabindex="0" aria-expanded="false">
                    </div>
    
                </div>
                <div class="right-side">
     
                    <!-- Header search box  -->
                    <div class="header_search"><i class="uil-search-alt"></i> 
                        <input value="" type="text" class="form-control" placeholder=" Recherche rapide ..." autocomplete="off" aria-expanded="false">
                        
                    </div>


                    <div>
        
                         <!-- profile -->
                        <a href="#" aria-expanded="false">
                            <img src="../assets/images/avatars/placeholder.png" class="header_widgets_avatar" alt="">
                        </a>
                        <div uk-drop="mode: click;offset:5" class="header_dropdown profile_dropdown uk-drop">
                            <ul>   
                                <li>
                                    <a href="#" class="user">
                                        <div class="user_avatar">
                                            <img src="../assets/images/avatars/avatar-2.jpg" alt="">
                                        </div>
                                        <div class="user_name">
                                            <div> Stella Johnson </div>
                                            <span> @Johnson  </span>
                                        </div>
                                    </a>
                                </li>
                                <li> 
                                    <hr>
                                </li>
                                <li> 
                                    <a href="#" class="is-link">
                                        <ion-icon name="rocket-outline" class="is-icon md hydrated" role="img" aria-label="rocket outline"></ion-icon> <span>  Upgrade Membership  </span>
                                    </a>
                                </li> 
                                <li> 
                                    <hr>
                                </li>
                                <li> 
                                    <a href="#">
                                        <ion-icon name="person-circle-outline" class="is-icon md hydrated" role="img" aria-label="person circle outline"></ion-icon>
                                         My Account 
                                    </a>
                                </li>
                                <li> 
                                    <a href="#">
                                        <ion-icon name="card-outline" class="is-icon md hydrated" role="img" aria-label="card outline"></ion-icon>
                                        Subscriptions
                                    </a>
                                </li>
                                <li> 
                                    <a href="#">
                                        <ion-icon name="color-wand-outline" class="is-icon md hydrated" role="img" aria-label="color wand outline"></ion-icon>
                                        My Billing 
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <ion-icon name="settings-outline" class="is-icon md hydrated" role="img" aria-label="settings outline"></ion-icon>
                                        Account Settings  
                                    </a>
                                </li>
                                <li> 
                                    <hr>
                                </li>
                                <li> 
                                    <a href="#" id="night-mode" class="btn-night-mode" onclick="UIkit.notification({ message: 'Hmm...  <strong> Night mode </strong> feature is not available yet. ' , pos: 'bottom-right'  })">
                                        <ion-icon name="moon-outline" class="is-icon md hydrated" role="img" aria-label="moon outline"></ion-icon>
                                         Night mode
                                        <span class="btn-night-mode-switch">
                                            <span class="uk-switch-button"></span>
                                        </span>
                                    </a>
                                </li>
                                <li> 
                                    <a href="#">
                                        <ion-icon name="log-out-outline" class="is-icon md hydrated" role="img" aria-label="log out outline"></ion-icon>
                                        Log Out 
                                    </a>
                                </li>
                            </ul>
                        </div> 

                    </div>
    
                </div>
            </div>
        </header>

        <!-- Main Contents -->
        <div class="main_content">
            <div class="container p-0">

                <div class="bg-blue-600 md:rounded-b-lg md:-mt-8 md:pb-8 md:pt-12 p-8 relative overflow-hidden" style="background: #1877f2;">

                    <div class="lg:w-9/12 relative z-10">

                        <div class="uppercase text-gray-200 mb-2 font-semibold text-sm"> <?php echo e($exercise->module->title); ?> </div>
                        <h1 class="lg:leading-10 lg:text-3xl text-white text-2xl leading-8 font-semibold"> Exercice N°<?php echo e($exercise->id); ?> : <?php echo e($exercise->title); ?> </h1>
                        
                        

                    </div>

                    <img src="../assets/images/courses/course-intro.png" alt="" class="-bottom-1/2 absolute right-0 hidden lg:block">

                </div>
                 
                <div class="lg:flex lg:space-x-4 mt-4">
                    <div class="space-y-4">
                        
                        <div class="tube-card z-20 mb-4 overflow-hidden uk-sticky" uk-sticky="cls-active:rounded-none ; media: 992 ; offset:70" style="">
                            <nav class="cd-secondary-nav extanded ppercase nav-small">
                                <ul class="space-x-3" uk-scrollspy-nav="closest: li; scroll: true">
                                    <li class="uk-active"><a href="#Overview" uk-scroll="">SUJET</a></li>
                                    <li class=""><a href="#curriculum" uk-scroll="">SOLUTION</a></li> 
                                    <li class=""><a href="#faq" uk-scroll="">PDF</a></li>
                                </ul>
                            </nav>
                        </div><div class="uk-sticky-placeholder" style="height: 59px; margin: 0px 0px 16px;" hidden=""></div>


                        <!-- course description -->
                        <div class="tube-card p-6" id="Overview">
    
                            <h3 class="mb-4 text-xl font-semibold"> Sujet </h3>
                            <div class="space-y-7">
                                <?php echo $exercise->content; ?>

                            </div>

                        </div>

                        <!-- course Curriculum -->
                        <div id="curriculum">
                            <h3 class="mb-4 text-xl font-semibold"> Solution </h3>
                            <div class="tube-card p-4 divide-y space-y-3 uk-accordion">
                                <?php echo $exercise->solution->content; ?>                                
                            </div>
                        </div>

                        <!-- course Faq --> 
                        <div id="faq" class="tube-card p-5">
                            <h3 class="text-lg font-semibold mb-3"> Télécharger PDF </h3>
                            <ul uk-accordion="multiple: true" class="divide-y space-y-3 uk-accordion">
                                <li class="bg-gray-100 px-4 py-3 rounded-md uk-open">
                                    <a class="uk-accordion-title font-semibold text-base" href="#"> Html Introduction </a>
                                    <div class="uk-accordion-content mt-3">
                                        <p> The primary goal of this quick start guide is to introduce you to
                                            Unreal
                                            Engine 4`s (UE4) development environment. By the end of this guide,
                                            you`ll
                                            know how to set up and develop C++ Projects in UE4. This guide shows
                                            you
                                            how
                                            to create a new Unreal Engine project, add a new C++ class to it,
                                            compile
                                            the project, and add an instance of a new class to your level. By
                                            the
                                            time
                                            you reach the end of this guide, you`ll be able to see your
                                            programmed
                                            Actor
                                            floating above a table in the level. </p>
                                    </div>
                                </li>
                            </ul>
                        </div>


                    </div>

                    <!-- course intro Sidebar -->
                    
                </div>

            </div>

            <!-- footer -->
            <div class="lg:mt-28 mt-10 mb-7 px-12 border-t pt-7">
                <div class="flex flex-col items-center justify-between lg:flex-row max-w-6xl mx-auto lg:space-y-0 space-y-3">
                    <p class="capitalize font-medium"> © copyright <script>document.write(new Date().getFullYear())</script>  Courseplus</p>
                    <div class="lg:flex space-x-4 text-gray-700 capitalize hidden">
                        <a href=" <?php echo e(route('accueil')); ?> "> Accueil</a>
                        <a href="#"> Aide</a>
                        <a href="#"> Nous contactez</a>
                    </div>
                </div>
            </div>
        </div>
 
        <!-- sidebar -->
        <div class="sidebar">
            <div class="sidebar_inner" data-simplebar>
                
                <ul class="side-colored">
                    <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li 
                            <?php if($loop->odd): ?>
                                class="active"
                            <?php endif; ?>
                        >
                            <a href=" <?php echo e(route('module', ['slug' => $module->slug])); ?> ">
                                <ion-icon name="<?php echo e($module->icon); ?>" class="bg-gradient-to-br from-purple-300 p-1 rounded-md side-icon text-opacity-80 text-white to-blue-500">
                                </ion-icon>
                                <span> <?php echo e($module->title); ?></span>
                            </a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>


            </div>

        </div>
        
    </div>


    <!-- Javascript
    ================================================== -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/uikit@3.7.6/dist/js/uikit.min.js"></script>
    <script src="<?php echo e(asset('assets/js/uikit.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/tippy.all.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/simplebar.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap-select.min.js')); ?>"></script>
    <script src="https://unpkg.com/ionicons@5.2.3/dist/ionicons.js"></script>

</body>

</html>
<?php /**PATH C:\Users\eloss\Documents\Code_Lab\Laravel_Lab\chingInfo\resources\views/exercise/show.blade.php ENDPATH**/ ?>